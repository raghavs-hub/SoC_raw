#include<bits/stdc++.h>
using namespace std;
int main()
{
ios::sync_with_stdio(0);
cin.tie(0);
int t; cin >> t;
for(int i=0;i<t;i++){
    long long n,k;
    cin >> n >> k;
    if(n%2==0 || k%2==1) cout << "YES" << "\n";
    else cout << "NO" << "\n";}
}